//
//  DetailsViewController.swift
//  Machine task
//
//  Created by Mahendran on 08/07/21.
//

import UIKit
import SDWebImage

class DetailsViewController: UIViewController {
    
    
    
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblUserMail: UILabel!
    @IBOutlet weak var lblUserId: UILabel!

    
    var Index = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = false
        self.lblUserName.text! =   "Name: " + (Singletion.shared.userInfoArr[Index].userFName!) + (Singletion.shared.userInfoArr[Index].userLName!)
        self.lblUserMail.text! =  "MailID: " + (Singletion.shared.userInfoArr[Index].userMail!)
        
        self.lblUserId.text! = "UserID: " +  "\(Singletion.shared.userInfoArr[Index].userId!)"
        
        
        self.imgUser.sd_imageIndicator = SDWebImageActivityIndicator.gray
        self.imgUser.sd_setImage(with: URL(string: Singletion.shared.userInfoArr[Index].userImage!, relativeTo: nil))
        
    }
    
    
    
    @IBAction func onBtnSaveLocal(sender: UIButton)
    {
        
        StoreUserDetailsLocal(userImg: Singletion.shared.userInfoArr[Index].userImage!, userId: Int16(Singletion.shared.userInfoArr[Index].userId!), userFName: Singletion.shared.userInfoArr[Index].userFName!, userLName: Singletion.shared.userInfoArr[Index].userLName!, userMail: Singletion.shared.userInfoArr[Index].userMail!)
        
        
        
        
    }

}
