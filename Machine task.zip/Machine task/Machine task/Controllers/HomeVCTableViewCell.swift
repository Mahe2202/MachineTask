//
//  HomeVCTableViewCell.swift
//  Machine task
//
//  Created by Mahendran on 08/07/21.
//

import UIKit

class HomeVCTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblUserId: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblUserMail: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
