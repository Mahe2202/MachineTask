//
//  ViewController.swift
//  Machine task
//
//  Created by Mahendran on 08/07/21.
//

import UIKit
import SDWebImage

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var HomeVCTableView: UITableView!
    
    

        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        HomeVCTableView.register(UINib(nibName: "HomeVCTableViewCell", bundle: nil), forCellReuseIdentifier: "HomeVCTableViewCell")
        
        self.GETUSERDETAILSAPI()
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        
        self.navigationController?.isNavigationBarHidden = true
        
        
    }
    
    
    
    
    
    func GETUSERDETAILSAPI()
    {
        
        WebService.sharedInstance.webServiceInitialGETCall(url: "https://reqres.in/api/users", paramValues: [:], headerValues: [:]) { (error, Jsonresponse) in
            
            let arrData = Jsonresponse!["data"] as! Array<Any>
            
            
            Singletion.shared.getUserinfo(arr: arrData)
           
            self.HomeVCTableView.reloadData()
            
            
        }
        
        
    }
    

}


extension HomeViewController: UITableViewDelegate, UITableViewDataSource

{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Singletion.shared.userInfoArr.count
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeVCTableViewCell") as! HomeVCTableViewCell
        
        
        cell.lblUserId.text! = "UserID: " +  "\(Singletion.shared.userInfoArr[indexPath.row].userId!)"
        cell.lblUserName.text! = "Name: " + (Singletion.shared.userInfoArr[indexPath.row].userFName!) + (Singletion.shared.userInfoArr[indexPath.row].userLName!)
        cell.lblUserMail.text! = "MailID: " + (Singletion.shared.userInfoArr[indexPath.row].userMail!)
        cell.imgUser.sd_imageIndicator = SDWebImageActivityIndicator.gray
        cell.imgUser.sd_setImage(with: URL(string: Singletion.shared.userInfoArr[indexPath.row].userImage!, relativeTo: nil))

        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let goToNextVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        goToNextVC.Index = indexPath.row
        self.navigationController?.pushViewController(goToNextVC, animated: true)
        
        
    }
    
    
    
}

