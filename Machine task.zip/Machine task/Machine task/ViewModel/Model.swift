//
//  Model.swift
//  Machine task
//
//  Created by Mahendran on 08/07/21.
//

import Foundation
import CoreData
import UIKit


struct userDetails {
    var userFName : String?
    var userLName : String?
    var userMail : String?
    var userImage : String?
    var userId : Int16?
}


var userInfo = userDetails()

class Singletion {


    static var shared = Singletion()

    var userInfoArr = [userDetails]()
    
    func getUserinfo(arr: Array<Any>) {
        
        
        for arrData in arr
        {
            
            let dictData = arrData as? NSDictionary
            
            userInfo.userFName = dictData!["first_name"] as? String
            userInfo.userLName = dictData!["last_name"] as? String
            userInfo.userId =   dictData!["id"] as? Int16
            userInfo.userMail = dictData!["email"] as? String
            userInfo.userImage = dictData!["avatar"] as? String
            
            userInfoArr.append(userInfo)
            
            
        }
    
}
    
    

}


//MARK:- COREDATA User Data....

class UserDetails : NSManagedObject {
    
    
    @NSManaged var userFName : String?
    @NSManaged var userLName : String?
    @NSManaged var userMail : String?
    @NSManaged var userImage : String?
    @NSManaged var userId : Int16
    
    
}
