//
//  WebService.swift
//  Machine task
//
//  Created by Mahendran on 08/07/21.
//

import Foundation
import Alamofire

class WebService {
    
    struct Singleton {
        static let sharedInstance = WebService()
    }
    
    class var sharedInstance: WebService {
        
        return Singleton.sharedInstance
    }

    
    typealias LWebserviceStatusDictCompletionBlock = ( _ error : NSError?, _ responseDict : [String : AnyObject]?)  -> Void
    
    //MARK:- Webservice Get Dictonary method
    func webServiceInitialGETCall(url : String,paramValues : NSDictionary, headerValues : [String:String], completionBlock : @escaping LWebserviceStatusDictCompletionBlock) {
        

        Alamofire .request(url, method: .get, parameters: paramValues as? Parameters, encoding: URLEncoding.default, headers: headerValues) .responseJSON { response in
            
            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, responseDict as? [String : AnyObject])
            case .failure(let error):
                
                completionBlock(error as NSError?, nil)
            }
        }
    }
    
}
